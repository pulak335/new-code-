import moment from 'moment';
import {CartItem} from '../../lib/flowtypes';

import {isEmpty} from 'lodash';

import {formatMoney} from '../../lib/utils';

export const getKitchenReceiptForAdditionalItemsText = (
  order,
  cart,
  notes = '',
  waiterName,
  restaurantName,
) => {
  if (!cart.length) {
    return;
  }

  let items = '';
  cart.map((item, i) => {
    console.log('item.subtotal.toFixed step 2', item.subtotal);

    items += `[L]${item.qty}x ${item.name} [R]${item.subtotal}\n`;
  });

  notes = notes !== '' ? `[C]<b>**Note: ${notes}</b>\n` : '';

  const design =
    `[C]<font size='big'>${restaurantName}</font>\n` +
    '[L]\n' +
    '[L]\n' +
    `[L]${order.table.name} [R] Guest: ${order.guestCount}\n` +
    notes +
    '[L]<u>Item</u> [R]<u>Price</u>\n' +
    '[L]\n' +
    items +
    '[L]\n' +
    '[L]\n' +
    `[L]Ticket No. ${order.ticketNumber} [R]Assistant: ${waiterName}\n` +
    `[L]${moment().format('DD/MM/YYYY')} [R]${moment().format('h:mm a')}\n` +
    '[L]\n' +
    "[C]<font size='medium'>Thank You.</font>" +
    '[L]\n' +
    '[L]\n';

  return design;
};

const getVariants = (item) => {
  if (item.selectedVariants) {
    if (isEmpty(item.selectedVariants)) {
      return '';
    }
    if (item.selectedVariants.selectedName !== '') {
      return item.selectedVariants.selectedName;
    } else {
      return '';
    }
  } else {
    return '';
  }
};

const getComments = (item) => {
  console.log('item des', item.description);

  if (
    item.description !== null &&
    item.description !== '' &&
    item.description !== undefined
  ) {
    return item.description;
  } else {
    return '';
  }
};

export const getItemsSectionWithSubtotal = (
  items: Array<CartItem>,
  gapBetweenItems = true,
  subTotal,
  context,
) => {
  if (!items.length) {
    return '';
  }

  const gap = gapBetweenItems ? '[L]\n' : '';
  let design =
    `[L]<u>Item</u> [R]<u>Price ${context.config.currency.toUpperCase()}</u>\n` +
    '[L]\n' +
    '[L]\n';

  console.log('items are com', items);

  items.map((item, i) => {
    let subTotal =
      item?.subtotal !== undefined ? parseFloat(item?.subtotal) : 0;

    design += `[L]${item.qty}x ${item.name} ${getVariants(
      item,
    )} [R]  ${subTotal.toFixed(2)}\n`;

    if (item.selectedAddon.length > 0) {
      let ShowData = item.selectedAddon.filter((e) => e.totalSelected > 0);

      let ShowItemAdd = [];

      if (ShowData.length > 0) {
        ShowData.map((e) => {
          if (e.selectedItem.length > 0) {
            ShowItemAdd.length > 0
              ? (ShowItemAdd = [...ShowItemAdd, ...e.selectedItem])
              : (ShowItemAdd = e.selectedItem);
          }
        });
      }

      if (ShowItemAdd.length > 0) {
        const finalShowItemAdd = ShowItemAdd.filter(({price})=>price>0)
        finalShowItemAdd.map(
          (e) =>
            (design += `[L]   ${e.totalSelected}x ${e.name}  (${parseInt(
              e.price
            ).toFixed(2)} )\n`),
        );
      }
    }

    design += `[L]${getComments(item)} \n`;

    design += gap;
  });

  const subtotalpart =
    '[L]\n' +
    `[L]<b>Total<b> [R]<b>${
      context.config.currency.toUpperCase() + ' ' + subTotal.toFixed(2)
    }</b>\n` +
    '[L]\n';

  console.log('subtotalpart', design + subtotalpart);

  return design + subtotalpart;
};

export const getNote = (note) => {
  if (note === undefined || note === null) {
    return '';
  }

  if (note === '') {
    return '';
  }

  return `[L]<b>**Note:</b> ${note}\n`;
};

export const getTicketBottom = (ticketNumber, waiterName) => {
  const design =
    `[L]Ticket No. ${ticketNumber} [R]Assistant: ${waiterName}\n` +
    `[L]${moment().format('h:mm a')} [R]${moment().format('DD/MM/YYYY')}\n` +
    '[L]\n' +
    "[L] [C]<font size='big'>Thank You.</font> [R]\n" +
    '[L]\n' +
    '[L]\n';

  return design;
};
