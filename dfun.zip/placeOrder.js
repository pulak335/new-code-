/*
this functions directory contains the actual business logic of the system
all the exported functions here has one input, the context state, and they
return a modified sub object of the state, which then will be merged with the
context state again
* */
import {v4 as uuidv4} from 'uuid';
import c from 'currency.js';
import {pick} from 'lodash';
import {calculateCartTotals, getCartTotal} from '../../lib/business';
import {
  ORDERSTATUS_PROCESSING,
  ORDERTYPE_COLLECTION,
  ORDERTYPE_DELIVERY,
  PAYMENT_UNPAID,
} from '../../lib/constants';
import {initialCartTotals, initialPaidBy} from '../emptyStates';
import {getInvoiceNo} from '../../lib/utils';

const _ = require('lodash');

export function getVatDetails(config, cartTotals) {
  if (config.vat_amount) {
    let vat = {
      amount: c(config.vat_amount).value,
    };
    vat.percent =
      config.vat_percent && config.vat_percent === '1' ? true : false;
    vat.final = vat.percent
      ? c((vat.amount / 100) * cartTotals.subtotal).value
      : vat.amount;
    return vat;
  }

  return cartTotals.vat;
}

export function getScDetails(config, cartTotals) {
  if (config.sc_amount) {
    let sc = {
      amount: c(config.sc_amount).value,
    };
    sc.percent = config.sc_percent && config.sc_percent === '1' ? true : false;
    sc.final = sc.percent
      ? c((sc.amount / 100) * cartTotals.subtotal).value
      : sc.amount;
    return sc;
  }

  return cartTotals.sc;
}

export function getDcDetails(config, cartTotals) {
  if (config.delivery_amount) {
    let dc = {
      amount: c(config.delivery_amount).value,
    };
    dc.percent =
      config.delivery_percent && config.delivery_percent === '1' ? true : false;
    dc.final = dc.percent
      ? c((dc.amount / 100) * cartTotals.subtotal).value
      : dc.amount;
    return dc;
  }

  return cartTotals.dc;
}

//collection discount
export function getCdDetails(config, cartTotals) {
  if (config.cd_amount) {
    let cd = {
      amount: c(config.cd_amount).value,
    };
    cd.percent = config.cd_percent && config.cd_percent === '1' ? true : false;
    cd.final = cd.percent
      ? c((cd.amount / 100) * cartTotals.subtotal).value
      : cd.amount;
    return cd;
  }

  return cartTotals.cd;
}

export const placeOrder = (state, ticketNumber) => {
  const {orderType, cart, cartTotals, guestCount, activeTable} = state;
  const orderId = uuidv4();

  // calculate vat & sc of cartTotals
  const {config} = state;

  cartTotals.vat = getVatDetails(config, cartTotals);
  cartTotals.sc = getScDetails(config, cartTotals);
  cartTotals.total = getCartTotal(cartTotals);

  return {
    cart,
    cartTotals,
    orderType,
    guestCount,
    table: activeTable,
    paymentStatus: PAYMENT_UNPAID,
    orderStatus: ORDERSTATUS_PROCESSING,
    ticketNumber,
    notes: state.notes,
    orderId,
    paidBy: initialPaidBy(),
    orderTime: new Date(),
  };
};

export const placeCollectionOrder = (
  state,
  ticketNumber,
  paymentStatus = PAYMENT_UNPAID,
) => {
  const {cart, cartTotals, customerInfo, orderMeta, config} = state;
  const orderId = uuidv4();
  const invoiceNo = getInvoiceNo(ticketNumber);

  // calculate vat & sc of cartTotals
  cartTotals.vat = getVatDetails(config, cartTotals);
  cartTotals.cd = getCdDetails(config, cartTotals);
  cartTotals.total = getCartTotal(cartTotals);

  return {
    cart,
    cartTotals,
    orderType: ORDERTYPE_COLLECTION,
    paymentStatus,
    ticketNumber,
    orderStatus: ORDERSTATUS_PROCESSING,
    notes: state.notes,
    paidBy: initialPaidBy(),
    customerInfo,
    orderId,
    collectionTime: orderMeta.collectionTime,
    collectionNote: orderMeta.collectionNote,
    invoiceNo,
    orderTime: new Date(),
  };
};

export const placeDeliveryOrder = (
  state,
  ticketNumber,
  paymentStatus = PAYMENT_UNPAID,
) => {
  const {cart, cartTotals, customerInfo, orderMeta, config} = state;
  const orderId = uuidv4();
  const invoiceNo = getInvoiceNo(ticketNumber);

  // calculate vat & sc of cartTotals
  cartTotals.vat = getVatDetails(config, cartTotals);
  cartTotals.dc = getDcDetails(config, cartTotals);
  cartTotals.total = getCartTotal(cartTotals);
  // the addresses inside customerInfo are actually delivery address
  const deliveryAddress = pick(customerInfo, [
    'name',
    'phone',
    'post_code',
    'address_1',
    'address_2',
    'town',
    'county',
  ]);
  return {
    cart,
    cartTotals,
    orderType: ORDERTYPE_DELIVERY,
    paymentStatus,
    ticketNumber,
    orderStatus: ORDERSTATUS_PROCESSING,
    notes: state.notes,
    paidBy: initialPaidBy(),
    customerInfo,
    deliveryAddress,
    orderId,
    deliveryTime: orderMeta.deliveryTime,
    deliveryNote: orderMeta.deliveryNote,
    invoiceNo,
    orderTime: new Date(),
  };
};

export const getOrderByTableId = (state, tableId) => {
  const {activeOrders} = state;
  if (_.isEmpty(activeOrders)) {
    return null;
  }
  let order = null;
  if (activeOrders.length) {
    activeOrders.map((item, i) => {
      if (item.table && item.table.id === tableId) {
        order = item;
      }
    });
  }

  return order;
};

// merge cart items & also calculate cart total for active order
export const mergeCartItemToOrder = (state) => {
  const {activeOrders, cart, activeOrderId} = state;

  if (_.isEmpty(cart)) {
    return activeOrders;
  }

  if (_.isEmpty(activeOrders)) {
    return {};
  }

  if (activeOrders.length) {
    const updated = activeOrders.map((order, i) => {
      if (order.orderId === activeOrderId) {
        // loop through new  cart items
        // if item already exists in order
        // update qty & subtotal
        // rmeove the item from orderCart
        // then push to ordercart
        // else push as is
        let orderCart = order.cart;

        cart.map((item, i) => {
          let f = orderCart.find((el) => el.fooditem_id == item.fooditem_id);
          if (f) {
            f.qty = item.qty + f.qty;
            f.subtotal = item.subtotal + f.subtotal;
            _.remove(orderCart, (el) => el.fooditem_id == item.fooditem_id);
            orderCart.push(f);
          } else {
            orderCart.push(item);
          }
        });

        order.cart = orderCart;
        let cartTotals = calculateCartTotals(orderCart);
        cartTotals.vat = getVatDetails(state.settings, cartTotals);
        cartTotals.sc = getScDetails(state.settings, cartTotals);
        cartTotals.total = getCartTotal(cartTotals);
        order.cartTotals = cartTotals;
      }
      return order;
    });
    return updated;
  }

  return activeOrders;
};

/*
 * orders are mapped by table, 1 table can have only 1 order at a time
 * check for activeTable in the state, to get active order, find order for that
 * table id
 * */
export const getActiveOrder = (state) => {
  const {activeOrders, activeTable} = state;
  // console.log({activeOrders});
  // console.log({activeTable});
  if (_.isEmpty(activeOrders)) {
    return {};
  }
  if (_.isEmpty(activeTable)) {
    return null;
  }

  let order = {};
  if (activeOrders.length) {
    activeOrders.map((item, i) => {
      if (item.table.id === activeTable.id) {
        order = item;
      }
    });
  }

  return order;
};

export const removeActiveOrder = (state) => {
  const {activeOrders, activeTable} = state;
  if (_.isEmpty(activeOrders)) {
    return {};
  }
  if (_.isEmpty(activeTable)) {
    return null;
  }

  let order = {};
  if (activeOrders.length) {
    activeOrders.map((item, i) => {
      if (item.table.id === activeTable.id) {
        order = item;
      }
    });
  }

  return order;
};

// this is used in places where an valid empty order obj is needed
// so that we don't face cant get property of undfined error when
// accessing nested valuues like order.cartTotals.total
export const emptyOrderObj = () => {
  return {
    cartTotals: initialCartTotals(),
  };
};
