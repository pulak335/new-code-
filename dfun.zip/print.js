import moment from 'moment';
import {startCase} from 'lodash';
import {displayMoney, formatTimestamp, getInvoiceNo} from '../../lib/utils';
import {sortCartItemsByMenu} from '../../lib/business';
import {printByIpAndPort} from '../../lib/printer';
import {
  getItemsSectionWithSubtotal,
  getKitchenReceiptForAdditionalItemsText,
  getNote,
  getTicketBottom,
} from './printDesigns';

export const printDineInKitchenReceipt = async (
  order,
  departments,
  printers,
  waiterName,
  storeName,
  context,
) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  // formatMoney(
  //   appOrderList.totalAmount,
  //   context.config.currency,
  // )

  console.log('fucking print here');

  departments.map(async (dept) => {
    // get items by dept id
    const filteredItems = cart.filter((i) => i.department.id === dept.id);

    // proceed only if there's any items
    if (filteredItems.length) {
      const sorted = sortCartItemsByMenu(filteredItems);
      let items = getItemsSectionWithSubtotal(
        sorted,
        true,
        order.cartTotals.total,
        context,
      );

      const bottom = getTicketBottom(order.ticketNumber, waiterName);

      let notes = getNote(order.notes);

      const design =
        `[C]<font size='big'>${storeName}</font>\n` +
        '[L]\n' +
        '[L]\n' +
        `[L]<b><font size='medium'>${order.table.name}</font></b> [R] <b><font size='medium'>Guest: ${order.guestCount}</font></b>\n` +
        '[L]\n' +
        notes +
        '[L]\n' +
        items +
        // `[R]<font size='big'><b>${startCase(
        //   order.paymentStatus,
        // )}</b></font>\n` +
        // '[L]\n' +

        bottom;

      if (__DEV__) {
        console.log('dev >', design);
      }
      // get printer for this dept
      const printer = printers.find((el) => el.departments.includes(dept.id));

      console.log('Printter', printer);
      // do print
      if (printer) {
        await printByIpAndPort(printer.ip, printer.port, design);
      }
    }
  });
};

export const printDineInKitchenReceiptForAdditionalItems = async (
  order,
  cart,
  notes = '',
  departments,
  printers,
  waiterName,
  storeName,
  context,
) => {
  if (!cart.length) {
    return;
  }

  departments.map(async (dept) => {
    // get items by dept id
    const filteredItems = cart.filter((i) => i.department.id === dept.id);

    // proceed only if there's any items
    if (filteredItems.length) {
      const sorted = sortCartItemsByMenu(filteredItems);
      let items = getItemsSectionWithSubtotal(
        sorted,
        true,
        order.cartTotals.total,
        context,
      );

      const bottom = getTicketBottom(order.ticketNumber, waiterName);

      let notes = getNote(order.notes);

      const design =
        `[C]<font size='big'>${storeName}</font>\n` +
        '[L]\n' +
        '[L]\n' +
        `[L]<b><font size='medium'>${order.table.name}</font></b> [R] <b><font size='medium'>Guest: ${order.guestCount}</font></b>\n` +
        '[L]\n' +
        notes +
        '[L]\n' +
        items +
        bottom;
      if (__DEV__) {
        console.log(design);
      }
      // get printer for this dept
      const printer = printers.find((el) => el.departments.includes(dept.id));

      //console.log({printer});
      // do print
      if (printer) {
        await printByIpAndPort(printer.ip, printer.port, design);
      }
    }
  });
};

export const printCollectionKitchenReceipt = (
  order,
  departments,
  printers,
  waiterName,
  storeName,
) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  let colTime = '';
  if (order.collectionTime) {
    const time = formatTimestamp(order.collectionTime.time);
    const asap =
      order.collectionTime && order.collectionTime.asap ? 'ASAP' : '';
    colTime = `${asap} ${time}`;
  }

  departments.map(async (dept) => {
    // get items by dept id
    const filteredItems = cart.filter((i) => i.department.id === dept.id);

    // proceed only if there's any items
    if (filteredItems.length) {
      const sorted = sortCartItemsByMenu(filteredItems);
      let items = getItemsSectionWithSubtotal(
        sorted,
        true,
        order.cartTotals.total,
      );
      const bottom = getTicketBottom(order.ticketNumber, waiterName);
      let notes = getNote(order.notes);
      const colNote = order.collectionNote
        ? `**msg: ${order.collectionNote}`
        : '';
      const design =
        `[C]<font size='big'>${storeName}</font>\n` +
        '[L]\n' +
        `[C]COLLECTION at ${colTime}\n` +
        `[C]Name: ${order.customerInfo.name}\n` +
        '[L]\n' +
        notes +
        '[L]\n' +
        items +
        `[R]<font size='big'><b>${startCase(
          order.paymentStatus,
        )}</b></font>\n` +
        '[L]\n' +
        `[L]${colNote}\n` +
        '[L]\n' +
        bottom;

      if (__DEV__) {
        console.log('MMO', design);
      }
      // get printer for this dept
      const printer = printers.find((el) => el.departments.includes(dept.id));

      //console.log({printer});
      // do print
      if (!__DEV__) {
        if (printer) {
          await printByIpAndPort(printer.ip, printer.port, design);
        }
      }
    }
  });
};

export const printDeliveryKitchenReceipt = (
  order,
  departments,
  printers,
  waiterName,
  storeName,
) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  let colTime = '';
  if (order.deliveryTime) {
    const time = formatTimestamp(order.deliveryTime.time);
    const asap = order.deliveryTime && order.deliveryTime.asap ? 'ASAP' : '';
    colTime = `${asap} ${time}`;
  }

  departments.map(async (dept) => {
    // get items by dept id
    const filteredItems = cart.filter((i) => i.department.id === dept.id);

    // proceed only if there's any items
    if (filteredItems.length) {
      const sorted = sortCartItemsByMenu(filteredItems);

      let items = getItemsSectionWithSubtotal(
        sorted,
        true,
        order.cartTotals.total,
      );
      const bottom = getTicketBottom(order.ticketNumber, waiterName);
      let notes = getNote(order.notes);
      const deliveryNote = order.deliveryNote
        ? `<b>**msg:</b> ${order.deliveryNote}`
        : '';
      const delAddress = getDeliveryAddress(order);
      const design =
        `[C]<font size='big'>${storeName}</font>\n` +
        '[L]\n' +
        `[C][DELIVERY] at ${colTime}\n` +
        '[L]\n' +
        notes +
        '[L]\n' +
        items +
        `[R]<font size='big'><b>${startCase(
          order.paymentStatus,
        )}</b></font>\n` +
        '[L]\n' +
        `[L]${deliveryNote}\n` +
        '[L]\n' +
        `${delAddress}` +
        '[L]\n' +
        `[L]<b>Mobile No: ${order.customerInfo.phone}</b> \n` +
        '[L]\n' +
        bottom;

      if (__DEV__) {
        console.log(design);
      }
      // get printer for this dept
      const printer = printers.find((el) => el.departments.includes(dept.id));

      //console.log({printer});
      // do print
      if (!__DEV__) {
        if (printer) {
          await printByIpAndPort(printer.ip, printer.port, design);
        }
      }
    }
  });
};

function getTimeDelivery(order) {
  let t = '';
  if (order.deliveryTime) {
    if (order.deliveryTime.asap) {
      t = 'ASAP ' + formatTimestamp(order.deliveryTime.time);
    } else {
      t = formatTimestamp(order.deliveryTime.time);
    }
  }
  return t;
}

function getDeliveryAddress(order) {
  return (
    '[L]Delivery Address: \n' +
    `[L]${order.customerInfo.name} \n` +
    `[L]${order.deliveryAddress.address_1} \n` +
    `[L]${order.deliveryAddress.town} \n` +
    `[L]${order.deliveryAddress.county} \n` +
    `[L]${order.deliveryAddress.post_code} \n`
  );
}

export const getKitchenReceiptTextForDeliveryOrder = (order) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  let items = '';
  cart.map((item, i) => {
    items += `[L]${item.qty}x ${item.name} [R]${item.subtotal}\n`;
  });

  let notes = order.notes ? `[C]<b>**Note: ${order.notes}</b>\n` : '';
  let dnotes = order.deliveryNote
    ? `[L]<b>**Delivery Note: ${order.deliveryNote}</b>\n`
    : '';
  let colTime = getTimeDelivery(order);
  let address = getDeliveryAddress(order);

  const design =
    "[C]<font size='big'>Restaurant Name</font>\n" +
    '[L]\n' +
    `[C]DELIVERY at ${colTime}\n` +
    notes +
    '[L]<u>Item</u> [R]<u>Price</u>\n' +
    '[L]\n' +
    items +
    '[L]\n' +
    `[L]<b>Total<b> [R]<b>${order.cartTotals.total.toFixed(2)}</b>\n` +
    `[R]<b>${order.paymentStatus}</b>\n` +
    '[L]\n' +
    dnotes +
    address +
    `[L]<b>Mobile No: ${order.customerInfo.phone}</b> \n` +
    '[L]\n' +
    `[L]Ticket No. ${order.ticketNumber} [R]Assistant: Ali\n` +
    `[L]${moment().format('h:mm a')} [R]${moment().format('DD/MM/YYYY')}\n` +
    '[L]\n' +
    "[L][C]<font size='big'>Thank You.</font>" +
    '[L]\n' +
    '[L]';

  return design;
};

function getTotalsDesign(order) {
  const {cartTotals} = order;

  let d = `[R]<b>SubTotal: ${displayMoney(cartTotals.subtotal, false)}</b>\n`;

  if (cartTotals.sc.amount) {
    d += cartTotals.sc.percent
      ? `[R]Service:   ${cartTotals.sc.amount}%   ${displayMoney(
          cartTotals.sc.final,
          false,
        )}\n`
      : `[R]Service:   ${displayMoney(cartTotals.sc.final, false)}\n`;
  }

  if (cartTotals.cd && cartTotals.cd.amount) {
    d += cartTotals.cd.percent
      ? `[R]Collection:   ${cartTotals.cd.amount}%   -${displayMoney(
          cartTotals.cd.final,
          false,
        )}\n`
      : `[R]Collection:   -${displayMoney(cartTotals.cd.final, false)}\n`;
  }

  if (cartTotals.dc && cartTotals.dc.amount) {
    d += cartTotals.dc.percent
      ? `[R]Delivery:   ${cartTotals.dc.amount}%   ${displayMoney(
          cartTotals.dc.final,
          false,
        )}\n`
      : `[R]Delivery:   ${displayMoney(cartTotals.dc.final, false)}\n`;
  }

  // if (cartTotals.delivery_fee) {
  //   d += `[R]Delivery:   ${displayMoney(cartTotals.delivery_fee, false)}\n`;
  // }

  if (cartTotals.vat.amount) {
    d += cartTotals.vat.percent
      ? `[R]VAT:   ${cartTotals.vat.amount}%   ${displayMoney(
          cartTotals.vat.final,
          false,
        )}\n`
      : `[R]VAT:   ${displayMoney(cartTotals.vat.final, false)}\n`;
  }

  if (cartTotals.tips.amount) {
    d += cartTotals.tips.percent
      ? `[R]Tips:   ${cartTotals.tips.amount}%   ${displayMoney(
          cartTotals.tips.final,
          false,
        )}\n`
      : `[R]Tips:   ${displayMoney(cartTotals.tips.final, false)}\n`;
  }

  if (cartTotals.discount.amount) {
    d += cartTotals.discount.percent
      ? `[R]Discount:   ${cartTotals.discount.amount}%   -${displayMoney(
          cartTotals.discount.final,
          false,
        )}\n`
      : `[R]Discount:   -${displayMoney(cartTotals.discount.final, false)}\n`;
  }

  d += `[R]<b>TOTAL:<b> <b>${displayMoney(cartTotals.total, false)}</b>\n`;

  return d;
}

function getHeaderForReceipt(config) {
  let design = `[C]<font size='big'>${config.store_name}</font>\n`;
  if (config.address_line1) {
    design += `[C]${config.address_line1}\n`;
  }
  if (config.address_line2) {
    design += `[C]${config.address_line2}\n`;
  }
  if (config.town) {
    design += `[C]${config.town}`;
  }
  if (config.county) {
    design += `, ${config.county}\n`;
  } else {
    design += ' \n';
  }
  if (config.postal_code) {
    design += `[C]${config.postal_code}\n`;
  }
  design += '[L]\n';
  if (config.phone1) {
    design += `[C]Phone: ${config.phone1}`;
  }
  if (config.phone2) {
    design += `, ${config.phone2}`;
  }
  if (config.website) {
    design += `\n[C]${config.website}\n`;
  }

  return design;
}

function getPaidByDesign(order) {
  let design = '[C]<u>Paid by</u>\n';
  const {paidBy} = order;

  if (paidBy.cash) {
    design += `[R]Cash: ${displayMoney(paidBy.cash, false)}\n`;
  }
  if (paidBy.card) {
    design += `[R]Card: ${displayMoney(paidBy.card, false)}\n`;
  }
  //TODO voucjer & loyalty

  design +=
    `[R]<b>CHANGE</b>: ${displayMoney(paidBy.change, false)}\n` + '[L]\n';

  return design;
}

export const getInvoiceReceiptText = (order, config, waiterName, context) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  const invoiceId = getInvoiceNo(order.ticketNumber);
  const cartSorted = sortCartItemsByMenu(cart);
  let items = '';
  // cartSorted.map((item, i) => {
  //   items += `[L]${item.qty}x ${item.name} [R]${item.subtotal}\n`;
  // });

  console.log('hiteddd');
  let sample = getItemsSectionWithSubtotal(
    cartSorted,
    true,
    order.cartTotals.total,
    context,
  );

  items = sample;

  const totals = getTotalsDesign(order);
  const header = getHeaderForReceipt(config);
  const paidBy = getPaidByDesign(order);

  // need to update here

  const design =
    header +
    '[L] [C]--------------------------------------------------------------------- [R]' +
    '[L]\n' +
    '[L]\n' +
    `[L]<u>Item</u> [R]<u>Price ${context.config.currency.toUpperCase()} </u>\n` +
    '[L]\n' +
    items +
    '[L]\n' +
    totals +
    paidBy +
    `[L]Bill : ${invoiceId} [R]Assistant: ${waiterName}\n` +
    `[L]${moment().format('h:mm a')} [R]${moment().format('DD/MM/YYYY')}\n` +
    '[L]\n' +
    "[L] [C]<font size='big'>Thank You.</font> [R]\n" +
    '[L]\n' +
    '[L]\n';

  console.log('sample design is  ::: ', design);

  return design;
};

export const getCollectionOrderInvoiceReceiptText = (order, invoiceId, all) => {
  const cart = order.cart;
  if (!cart.length) {
    return;
  }

  let items = '';
  cart.map((item, i) => {
    items += `[L]${item.qty}x ${item.name} [R]${item.subtotal}\n`;
  });

  const totals = getTotalsDesign(order, all);

  const design =
    "[C]<font size='big'>Restaurant Name</font>\n" +
    '[C]63 New Road\n' +
    '[C]D2SCD\n' +
    '[C]Phone: 01725252\n' +
    '[L]--------------------------------------------------------------------' +
    '[L]\n' +
    '[L]<u>Item</u> [R]<u>Price</u>\n' +
    items +
    '[L]\n' +
    totals +
    '[C]<u>Paid by</u>\n' +
    `[R]Cash: ${displayMoney(all.paid, false)}\n` +
    `[R]<b>CHANGE</b>: ${displayMoney(all.change, false)}\n` +
    '[L]\n' +
    `[L]Bill No. ${invoiceId} [R]Assistant: Ali\n` +
    `[L]${moment().format('DD/MM/YYYY')} [R]${moment().format('h:mm a')}\n` +
    '[L]\n' +
    "[C]<font size='medium'>Thank You.</font>" +
    '[L]\n' +
    '[L]\n';

  return design;
};
